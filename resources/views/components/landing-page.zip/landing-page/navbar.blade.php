    @props(['navLinks'])

    <nav class="sticky top-0 z-50 bg-white/95 backdrop-blur-lg shadow-lg">
        <div class="max-w-7xl mx-auto px-4 py-2 flex items-center justify-between">
            <a class="flex items-center gap-2 no-underline" href="#beranda">
                <img src="{{ asset('img/rsi.png') }}" alt="Ruang Solusi Internusa Logo"
                    class="h-10 w-10 object-contain transition-transform duration-300 hover:scale-110">
                <span class="font-bold text-lg text-blue-800 hidden md:inline">Ruang Solusi Internusa</span>
            </a>

            <div class="flex items-center gap-2">
                <button
                    class="navbar-hamburger block lg:hidden w-10 h-10 p-2 text-blue-800 transition-colors duration-300 relative z-50"
                    id="navbarHamburger" aria-label="Toggle menu" aria-expanded="false" type="button">
                    <span
                        class="block w-full h-0.5 my-1 bg-blue-800 rounded-full transition-all duration-300 ease-in-out origin-[6px_center]"></span>
                    <span
                        class="block w-full h-0.5 my-1 bg-blue-800 rounded-full transition-all duration-300 ease-in-out"></span>
                    <span
                        class="block w-full h-0.5 my-1 bg-blue-800 rounded-full transition-all duration-300 ease-in-out origin-[6px_center]"></span>
                </button>

                <ul id="navbarLinks"
                    class="
    absolute top-full right-0 w-full h-[100dvh] md:w-auto md:h-auto flex flex-col gap-1
    list-none p-2 m-0 bg-white z-40
    transform -translate-y-2 opacity-0 scale-95 pointer-events-none transition-all duration-300
    lg:static lg:transform-none lg:opacity-100 lg:scale-100 lg:pointer-events-auto lg:flex-row lg:bg-transparent lg:shadow-none lg:backdrop-blur-none lg:w-auto lg:h-auto
">
                    @foreach ($navLinks as $link)
                        <x-landing-page.nav-link :href="$link['href']" :text="$link['text']" />
                    @endforeach
                </ul>
            </div>
        </div>
    </nav>
