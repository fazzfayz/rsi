<section id="kontak" class="py-16 md:py-24 bg-white fade-in">
    <div class="max-w-3xl mx-auto px-4">
        <div class="text-center mb-12">
            <h2 class="text-3xl md:text-5xl font-extrabold text-blue-800 tracking-wide mb-4">Hubungi Kami</h2>
            <p class="text-gray-600 text-lg md:text-xl max-w-2xl mx-auto">
                Siap bertransformasi digital? Kirimkan pesan Anda dan kami akan segera merespons.
            </p>
        </div>

        <div class="bg-gray-50 p-8 md:p-10 rounded-3xl shadow-xl">
            @if (session('success'))
                <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6" role="alert">
                    <p class="font-bold">Sukses!</p>
                    <p>{{ session('success') }}</p>
                </div>
            @endif
            <form action="{{ route('contact.send') }}" method="POST" class="space-y-6">
                @csrf
                <div>
                    <label for="name" class="block text-gray-700 font-semibold mb-2">Nama Lengkap</label>
                    <input type="text" id="name" name="name" required
                        class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-300">
                </div>
                <div>
                    <label for="email" class="block text-gray-700 font-semibold mb-2">Alamat Email</label>
                    <input type="email" id="email" name="email" required
                        class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-300">
                </div>
                <div>
                    <label for="message" class="block text-gray-700 font-semibold mb-2">Pesan Anda</label>
                    <textarea id="message" name="message" rows="5" required
                        class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-300 resize-none"></textarea>
                </div>
                <button type="submit"
                    class="w-full bg-blue-600 text-white font-bold py-3 rounded-xl hover:bg-blue-700 transition duration-300 shadow-lg">
                    Kirim Pesan
                </button>
            </form>
        </div>
    </div>
</section>