@props(['about', 'tags'])

<section id="tentang" class="relative py-16 md:py-24 bg-gradient-to-br from-blue-100 via-white to-blue-200 overflow-hidden fade-in">
    {{-- SVG Gelombang di Kiri Bawah --}}
    <div class="absolute -bottom-16 -left-32 opacity-20 pointer-events-none z-0">
        <svg class="w-[300px] h-[300px] md:w-[450px] md:h-[450px]" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
            <path fill="#93c5fd" d="M38.1,-33.5C49.9,-20.9,59.9,-10.5,61.9,2.4C64,15.3,58,30.6,47.9,40.4C37.8,50.1,23.6,54.4,9.6,53C-4.4,51.6,-18.3,44.5,-30.2,36.1C-42.1,27.7,-52,18,-58.3,4.4C-64.7,-9.1,-67.4,-27.4,-58.3,-39.8C-49.1,-52.3,-24.5,-59,-3.3,-57.4C18,-55.8,36,-45.8,38.1,-33.5Z" transform="translate(100 100)" />
        </svg>
    </div>

    {{-- SVG Pola Titik di Kanan Atas --}}
    <div class="absolute -top-16 -right-16 opacity-10 pointer-events-none z-0">
        <svg class="w-[150px] h-[150px] md:w-[200px] md:h-[200px]" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid slice" fill="none" xmlns="http://www.w3.org/2000/svg">
            <defs>
                <pattern id="pattern-dots" width="10" height="10" patternUnits="userSpaceOnUse">
                    <circle cx="1" cy="1" r="1" fill="#1e40af" />
                </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#pattern-dots)" />
        </svg>
    </div>

    <div class="relative max-w-6xl mx-auto px-4 z-10">
        {{-- Judul Utama --}}
        <h2 class="text-3xl md:text-5xl font-extrabold text-center mb-12">
            <span class="text-blue-800 tracking-wide">
                {{ $about->title ?? 'Tentang Kami' }}
            </span>
        </h2>

        <div class="flex flex-col md:flex-row items-center md:gap-16 gap-12">
            {{-- Bagian Gambar --}}
            <div class="w-full md:w-1/2 flex justify-center">
                <div class="relative group w-full max-w-md">
                    <div class="relative z-10 rounded-3xl overflow-hidden shadow-2xl transition-transform duration-300 group-hover:scale-105">
                        @if (isset($about) && $about->image)
                            <img src="{{ asset('storage/' . $about->image) }}" alt="Tentang Kami"
                                class="w-full h-56 md:h-[28rem] object-cover object-center">
                        @else
                            <img src="https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&w=600&q=80"
                                alt="Tim IT"
                                class="w-full h-56 md:h-[28rem] object-cover object-center">
                        @endif
                    </div>
                </div>
            </div>

            {{-- Bagian Konten --}}
            <div class="w-full md:w-1/2">
                <blockquote class="text-gray-700 text-lg md:text-xl mb-8 leading-relaxed italic border-l-4 border-blue-400 pl-4 md:pl-6">
                    {{ $about->description ?? 'Kami adalah tim profesional di bidang teknologi informasi yang berkomitmen menghadirkan solusi digital terbaik untuk bisnis Anda. Dengan pengalaman lebih dari 2 tahun, kami telah membantu berbagai perusahaan dalam pengembangan sistem, infrastruktur jaringan, dan keamanan informasi.' }}
                </blockquote>

                {{-- Judul Keunggulan Kami --}}
                <div class="inline-block relative mb-6">
                    <h3 class="text-xl md:text-2xl font-bold text-blue-800 flex items-center gap-3">
                      Keunggulan Kami
                    </h3>
                </div>

                <ul class="space-y-4">
                    @forelse (explode("\n", $about->list_items ?? "Tim berpengalaman & tersertifikasi\nTeknologi terbaru & inovatif\nLayanan personal & responsif") as $item)
                        <li class="flex items-center gap-3 text-base md:text-lg text-gray-800">
                            <span class="inline-flex items-center justify-center w-8 h-8 rounded-full bg-blue-500 text-white shadow-md">
                                <i class="fas fa-check"></i>
                            </span>
                            <span class="font-medium">{{ $item }}</span>
                        </li>
                    @empty
                        <li class="text-gray-500">Belum ada keunggulan yang ditambahkan.</li>
                    @endforelse
                </ul>

                <div class="flex flex-wrap gap-2 md:gap-3 mt-8">
                    @foreach ($tags as $tag)
                        <span class="inline-block bg-blue-100 text-blue-700 px-4 py-2 rounded-full text-sm font-semibold">{{ $tag['tag'] }}</span>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
</section>
