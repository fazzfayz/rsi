   <section id="beranda"
        class="relative min-h-screen flex items-center bg-gradient-to-br from-blue-600/10 via-white to-blue-200 overflow-hidden fade-in">
        {{-- Background Image --}}
        <div class="absolute inset-0 w-full h-full">
            <img src="https://images.unsplash.com/photo-1461749280684-dccba630e2f6?auto=format&fit=crop&w=1200&q=80"
                alt="Transformasi Digital IT" class="w-full h-full object-cover object-center opacity-30">
            <div class="absolute inset-0 bg-gradient-to-br from-blue-600/20 via-white/60 to-blue-200/80"></div>
        </div>
        <div class="relative z-10 max-w-4xl mx-auto px-4 text-center">
            <h2 class="text-5xl md:text-6xl font-extrabold text-blue-800 mb-6 leading-tight drop-shadow-lg">
                Selamat Datang di <span class="text-blue-500">Ruang Solusi Internusa</span>
            </h2>
            <p class="mb-8 text-lg text-gray-700 font-medium">
                Kami siap menjadi mitra teknologi Anda untuk menghadirkan solusi digital terbaik bagi perkembangan
                bisnis.
            </p>
            <a href="#layanan"
                class="inline-block bg-blue-700 text-white px-8 py-3 rounded-lg shadow-lg hover:bg-blue-800 transition font-semibold text-lg">
                Lihat Layanan Kami
            </a>
        </div>
    </section>
