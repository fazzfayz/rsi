<footer class="bg-blue-800 text-blue-200 py-8">
    <div class=" mx-auto px-4">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 md:gap-8">

            {{-- Kolom 1: Logo & Deskripsi --}}
            <div class="flex flex-col items-center md:items-start text-center md:text-left">
                <a href="#beranda" class="mb-2 text-3xl font-extrabold text-white"">
                    Ruang Solusi
                </a>
                <p class="text-sm leading-relaxed mb-4 max-w-xs mx-auto md:mx-0">
                    Kami adalah mitra strategis Anda dalam mewujudkan transformasi digital.
                    Berkomitmen menghadirkan solusi teknologi yang inovatif dan terukur.
                </p>
                <div class="flex justify-center md:justify-start gap-5">
                    <a href="https://instagram.com/distwnty" target="_blank"
                        class="text-2xl hover:text-pink-400 transition transform hover:scale-110">
                        <i class="fab fa-instagram"></i>
                    </a>
                    <a href="#" target="_blank"
                        class="text-2xl hover:text-blue-400 transition transform hover:scale-110">
                        <i class="fab fa-facebook"></i>
                    </a>
                    <a href="#" target="_blank"
                        class="text-2xl hover:text-blue-400 transition transform hover:scale-110">
                        <i class="fab fa-linkedin-in"></i>
                    </a>
                </div>
            </div>

            {{-- Kolom 2: Navigasi Cepat --}}
            <div class="text-center md:text-left">
                <h4 class="font-bold text-xl text-white mb-5">Navigasi</h4>
                <ul class="space-y-3">
                     @foreach ($navLinks as $link)
                     <li><a :href="$link['href']" class="hover:text-white cursor-pointer transition font-medium">{{ $link['text'] }}</a></li>
                     @endforeach
                </ul>
            </div>

            {{-- Kolom 3: Informasi Kontak --}}
            <div class="text-center md:text-left">
                <h4 class="font-bold text-xl text-white mb-5">Kontak Kami</h4>
                <address class="space-y-4 text-sm not-italic">
                    <div class="flex items-center justify-center md:justify-start">
                        <i class="fas fa-envelope text-blue-400 mr-3"></i>
                        <a href="mailto:info@ruang-solusi.com"
                            class="hover:text-white transition">info@ruang-solusi.com</a>
                    </div>
                    <div class="flex items-center justify-center md:justify-start">
                        <i class="fas fa-phone-alt text-blue-400 mr-3"></i>
                        <a href="tel:+6281287182682" class="hover:text-white transition">+62 812-8718-2682</a>
                    </div>
                    <div class="flex items-start justify-center md:justify-start">
                        <i class="fas fa-map-marker-alt text-blue-400 mr-3 mt-1 flex-shrink-0"></i>
                        <p>
                            Jl. Pondok Kelapa Timur No.11, Jakarta Timur, DKI Jakarta 13450
                        </p>
                    </div>
                </address>
            </div>
            <div class="flex w-full justify-center items-center lg:justify-end">
                <a href="https://wa.me/6281287182682" target="_blank"
                    class="inline-flex items-center px-4 py-2 bg-green-600 text-white font-semibold rounded-full shadow-lg hover:bg-green-700 transition transform hover:scale-105">
                    <i class="fab fa-whatsapp mr-2 text-lg"></i>
                    Chat via WhatsApp
                </a>
            </div>
        </div>

        {{-- Divider dan Copyright --}}
        <hr class="border-blue-700 my-2">
        <div class="text-center text-blue-300">
            <p class="text-sm">© {{ date('Y') }} Ruang Solusi Internusa. Hak Cipta Dilindungi.</p>
            <p class="mt-1 text-xs opacity-70">Design by Distwnty</p>
        </div>
    </div>
</footer>
