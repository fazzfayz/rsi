@props(['services'])


<section id="layanan" class="py-24 bg-gradient-to-br from-white via-white to-blue-50 relative fade-in">
    <div class="absolute inset-x-0 bottom-0 pointer-events-none opacity-50">
        <svg viewBox="0 0 1440 200" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M0 100Q360 50 720 100T1440 100V200H0V100Z" fill="#bfdbfe" />
            <path d="M0 120Q360 80 720 120T1440 120V200H0V120Z" fill="#eff6ff" />
        </svg>
    </div>

    <div class="relative max-w-7xl mx-auto px-4">
        <h3 class="text-4xl font-extrabold text-blue-700 mb-4 text-center">Layanan Unggulan Kami</h3>
        <p class="text-lg text-gray-600 mb-14 text-center max-w-2xl mx-auto">
            Kami menawarkan solusi digital terintegrasi untuk mendukung pertumbuhan bisnis Anda. Pilih layanan
            terbaik kami yang dirancang untuk kebutuhan modern.
        </p>

        <div class="grid md:grid-cols-3 gap-10">
            @forelse($services as $service)
                <div class="
                    group relative bg-white shadow-xl border border-blue-100 overflow-hidden rounded-2xl
                    fade-in transition-all duration-300 hover:shadow-2xl hover:-translate-y-2 cursor-pointer
                ">
                    <div class="w-full h-48 overflow-hidden transition-transform duration-300 group-hover:scale-105">
                        @if ($service->image)
                            <img src="{{ asset('storage/' . $service->image) }}" alt="{{ $service->title }}"
                                class="w-full h-full object-cover object-center transition-transform duration-300 group-hover:scale-105">
                        @else
                            <div class="w-full h-full flex items-center justify-center bg-blue-50 text-blue-300 text-4xl">
                                <i class="fa-solid fa-gear"></i>
                            </div>
                        @endif
                    </div>

                    <div class="pt-8 pb-8 px-6 transition-colors duration-300 group-hover:bg-blue-50">
                        <h4 class="text-2xl font-bold mb-3 text-blue-700 group-hover:text-blue-500 transition-colors duration-300">
                            {{ $service->title }}
                        </h4>
                        <p class="text-gray-600 mb-6 group-hover:text-gray-800 transition-colors duration-300">
                            {{ $service->description }}
                        </p>
                        @if ($service->label)
                            <span class="inline-block bg-blue-100 text-blue-700 px-4 py-1 rounded-full text-sm font-semibold
                                group-hover:bg-blue-500 group-hover:text-white transition-colors duration-300">
                                {{ $service->label }}
                            </span>
                        @endif
                    </div>
                </div>
            @empty
                <div class="col-span-3 text-center text-gray-400 py-12">Belum ada layanan tersedia.</div>
            @endforelse
        </div>
    </div>
</section>

